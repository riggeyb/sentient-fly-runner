from pathlib import Path
import re

root = Path("sentient")
compiler_path = root / "src/retrieval/context-compiler-v0.ts"
runtime_path = root / "src/runtime/sentient-runtime.ts"
test_path = root / "test/context-runtime-shadow-v0.test.ts"

compiler = compiler_path.read_text()
runtime = runtime_path.read_text()

for anchor in [
    "export async function compileContextV0(",
    "async function compileArtifacts(",
    "export async function resolveCompiledContextHandleV0(",
]:
    if anchor not in compiler:
        raise SystemExit(f"compiler anchor missing: {anchor}")
for anchor in [
    "async executeAdaptive(",
    "const execution = await router.execute(executor, adaptiveTask, stage);",
]:
    if anchor not in runtime:
        raise SystemExit(f"runtime anchor missing: {anchor}")

pat = re.compile(r'import type \{\s*([^}]+?)\s*\} from "\.\./model/types\.js";', re.S)
m = pat.search(compiler)
if not m:
    raise SystemExit("compiler model/types import block missing")
members = [x.strip() for x in m.group(1).split(",") if x.strip()]
if "PreparedTask" not in members:
    members.append("PreparedTask")
compiler = compiler[:m.start()] + 'import type { ' + ", ".join(members) + ' } from "../model/types.js";' + compiler[m.end():]

old_sig = 'async function compileArtifacts(input: ContextCompilerInputV0, compressor: ContextCompressorV0) {'
new_sig = '''async function compileArtifacts(
  input: Pick<ContextCompilerInputV0, "context" | "skills">,
  compressor: ContextCompressorV0,
) {'''
if old_sig not in compiler:
    raise SystemExit("compileArtifacts signature anchor missing")
compiler = compiler.replace(old_sig, new_sig, 1)

primary_fn = r'''
function preparedTaskObjective(task: PreparedTask): string {
  const content = task.messages
    .filter((message): message is Extract<PreparedTask["messages"][number], { role: "user" }> => message.role === "user")
    .map((message) => message.content)
    .join("\n\n")
    .trim();
  return content || `task:${task.taskId}`;
}

export async function compilePreparedTaskContextV0(
  task: PreparedTask,
  options: { compressor?: ContextCompressorV0 } = {},
): Promise<CompiledContextV0> {
  const compressor = options.compressor ?? new IdentityContextCompressorV0();
  const objective = preparedTaskObjective(task);
  const objectiveDigest = await sha256Text(objective);
  const c = await compileArtifacts({ context: task.context, skills: [] }, compressor);

  const constraintValues: Array<[string, JsonValue]> = [
    ["runtime:model-messages", jv(task.messages)],
    ["runtime:tools", jv(task.tools)],
    ["runtime:budget", jv(task.budget)],
    ["runtime:verifier", jv(task.verifier)],
    ["runtime:required-model-capabilities", jv(task.requiredModelCapabilities ?? [])],
  ];
  if (task.outputSchema !== undefined) constraintValues.push(["runtime:output-schema", jv(task.outputSchema)]);
  if (task.reasoningEffort !== undefined) constraintValues.push(["runtime:reasoning-effort", jv(task.reasoningEffort)]);
  if (task.cognitivePolicy !== undefined) constraintValues.push(["runtime:cognitive-policy", jv(task.cognitivePolicy)]);

  const invariantValues: Array<[string, JsonValue]> = [
    ["runtime:system-policy", jv(task.systemPolicy)],
    ["runtime:input-digest", jv(task.inputDigest)],
    ["runtime:identity", jv(task.runtime)],
    ["runtime:task-id", jv(task.taskId)],
    ["runtime:session-id", jv(task.sessionId)],
    ["runtime:trace-id", jv(task.traceId)],
  ];

  const constraints = await Promise.all(constraintValues.map(async ([canonicalIdentity, value], i) => ({
    alias: `C${i + 1}`, canonicalIdentity, value, digest: await sha256Json(value),
  })));
  const invariants = await Promise.all(invariantValues.map(async ([canonicalIdentity, value], i) => ({
    alias: `I${i + 1}`, canonicalIdentity, value, digest: await sha256Json(value),
  })));
  const symbols: CompiledContextSymbolV0[] = [
    { alias: "O1", kind: "objective", canonicalIdentity: "runtime:objective", digest: objectiveDigest, sourceHandle: null },
    ...c.symbols,
    ...constraints.map((x) => ({ alias: x.alias, kind: "constraint" as const, canonicalIdentity: x.canonicalIdentity, digest: x.digest, sourceHandle: null })),
    ...invariants.map((x) => ({ alias: x.alias, kind: "invariant" as const, canonicalIdentity: x.canonicalIdentity, digest: x.digest, sourceHandle: null })),
  ];
  const relationships: CompiledContextRelationshipV0[] = [
    ...c.relationships,
    ...constraints.map((x) => ({ from: "O1", relation: "requires_constraint" as const, to: x.alias })),
    ...invariants.map((x) => ({ from: "O1", relation: "preserves_invariant" as const, to: x.alias })),
  ];
  const raw = {
    taskId: task.taskId, sessionId: task.sessionId, traceId: task.traceId, runtime: task.runtime,
    systemPolicy: task.systemPolicy, messages: task.messages, context: task.context, tools: task.tools,
    outputSchema: task.outputSchema ?? null, reasoningEffort: task.reasoningEffort ?? null,
    requiredModelCapabilities: task.requiredModelCapabilities ?? [], budget: task.budget,
    verifier: task.verifier, cognitivePolicy: task.cognitivePolicy ?? null, inputDigest: task.inputDigest,
  };
  const payload = { objective, artifacts: c.artifacts, constraints, invariants, symbols, relationships, handles: c.handles };
  const rawContextTokens = jsonTokens(raw), compiledContextTokens = jsonTokens(payload);
  const exactEvidenceTokens = c.artifacts.filter((x) => x.lossSensitivity === "EXACT").reduce((n, x) => n + tokens(x.content), 0);
  const semanticCompressibleTokens = c.artifacts
    .filter((x) => x.lossSensitivity === "SEMANTIC_COMPRESSIBLE" || x.lossSensitivity === "SUMMARIZABLE")
    .reduce((n, x) => n + tokens(x.content), 0);
  const retention = {
    objectiveRetained: objective.length > 0,
    evidenceRetained: c.artifacts.every((x) => task.context.artifacts.some((a) => a.id === x.artifactId && a.contentDigest === x.contentDigest)),
    constraintRetention: constraints.length === constraintValues.length && constraints.every((x) => x.digest.length > 0)
      && invariants.length === invariantValues.length && invariants.every((x) => x.digest.length > 0),
    provenanceRetention: c.artifacts.every((x) => x.provenanceDigest.length > 0),
    exactMaterialRetained: c.artifacts.filter((x) => x.lossSensitivity === "EXACT")
      .every((x) => task.context.artifacts.find((a) => a.id === x.artifactId)?.content === x.content && !x.compressed),
    decisionRelevantInformationRetention: "PASS" as "PASS" | "FAIL",
  };
  if (!retention.objectiveRetained || !retention.evidenceRetained || !retention.constraintRetention
      || !retention.provenanceRetention || !retention.exactMaterialRetained) {
    retention.decisionRelevantInformationRetention = "FAIL";
  }
  const semanticCompressionEnabled = c.artifacts.some((x) => x.compressed);
  const base = {
    schemaVersion: CONTEXT_COMPILER_V0_VERSION, shadowMode: true as const,
    objective: { alias: "O1" as const, text: objective, digest: objectiveDigest, lossSensitivity: "EXACT" as const },
    artifacts: c.artifacts, constraints, invariants, symbols, relationships, handles: c.handles,
    accounting: {
      tokenEstimator: "ceil_utf8_bytes_div_4" as const, rawContextTokens, compiledContextTokens, exactEvidenceTokens,
      structuralTokens: jsonTokens({ symbols, relationships, handles: c.handles }), semanticCompressibleTokens,
      compressedNarrativeTokens: c.artifacts.filter((x) => x.compressed).reduce((n, x) => n + tokens(x.content), 0),
      contextCompressionRatio: rawContextTokens === 0 ? 1 : compiledContextTokens / rawContextTokens,
    },
    retention,
    compressor: {
      id: compressor.id, semanticCompressionEnabled,
      reason: semanticCompressionEnabled
        ? "explicit compressor transformed semantic-compressible segments"
        : "IdentityCompressor preserves narrative content in Context Compiler V0",
    },
    sourceContextDigest: task.context.contextDigest,
  };
  return { ...base, compilerDigest: await sha256Json(base) };
}
'''

resolver_anchor = 'export async function resolveCompiledContextHandleV0('
if 'export async function compilePreparedTaskContextV0(' not in compiler:
    compiler = compiler.replace(resolver_anchor, primary_fn + "\n" + resolver_anchor, 1)

runtime_import = 'import { rebudgetContextBundle } from "../retrieval/context-builder.js";'
if runtime_import not in runtime:
    raise SystemExit("runtime retrieval import anchor missing")
runtime = runtime.replace(
    runtime_import,
    runtime_import + '\nimport { compilePreparedTaskContextV0 } from "../retrieval/context-compiler-v0.js";'
    + '\nimport type { CompiledContextV0 } from "../retrieval/context-compiler-v0-contracts.js";',
    1,
)

old_iface = '''export interface AdaptiveRuntimeResult extends AtlasHybridExecution {
  preparedTask: PreparedTask;
  cognitiveState?: RuntimeCognitiveState;
}'''
new_iface = '''export interface AdaptiveRuntimeResult extends AtlasHybridExecution {
  preparedTask: PreparedTask;
  cognitiveState?: RuntimeCognitiveState;
  contextCompilerShadow?: CompiledContextV0;
  contextCompilerShadowError?: string;
}'''
if old_iface not in runtime:
    raise SystemExit("AdaptiveRuntimeResult anchor missing")
runtime = runtime.replace(old_iface, new_iface, 1)

old_nopolicy = '''    if (policy === undefined) {
      const execution = await router.execute(this, preparedTask, stage);
      return { ...execution, preparedTask };
    }'''
new_nopolicy = '''    if (policy === undefined) {
      const contextCompilerObservation = await compileContextCompilerShadowV0(stage, preparedTask);
      const execution = await router.execute(this, preparedTask, stage);
      return { ...execution, preparedTask, ...contextCompilerObservation };
    }'''
if old_nopolicy not in runtime:
    raise SystemExit("no-policy adaptive anchor missing")
runtime = runtime.replace(old_nopolicy, new_nopolicy, 1)

router_anchor = '    const execution = await router.execute(executor, adaptiveTask, stage);'
runtime = runtime.replace(
    router_anchor,
    '    const contextCompilerObservation = await compileContextCompilerShadowV0(stage, adaptiveTask);\n' + router_anchor,
    1,
)

old_return = '''    return {
      ...execution,
      preparedTask: adaptiveTask,
      cognitiveState,
    };'''
new_return = '''    return {
      ...execution,
      preparedTask: adaptiveTask,
      cognitiveState,
      ...contextCompilerObservation,
    };'''
if old_return not in runtime:
    raise SystemExit("adaptive return anchor missing")
runtime = runtime.replace(old_return, new_return, 1)

helper_anchor = 'export function toModelRequest(preparedTask: PreparedTask): ModelRequest {'
helper = '''async function compileContextCompilerShadowV0(
  stage: AtlasHybridStage,
  preparedTask: PreparedTask,
): Promise<Pick<AdaptiveRuntimeResult, "contextCompilerShadow" | "contextCompilerShadowError">> {
  if (stage !== "cognition") return {};
  try {
    return { contextCompilerShadow: await compilePreparedTaskContextV0(preparedTask) };
  } catch (error) {
    return { contextCompilerShadowError: error instanceof Error ? error.message : String(error) };
  }
}

'''
if 'async function compileContextCompilerShadowV0(' not in runtime:
    if helper_anchor not in runtime:
        raise SystemExit("runtime helper anchor missing")
    runtime = runtime.replace(helper_anchor, helper + helper_anchor, 1)

test = r'''import assert from "node:assert/strict";
import test from "node:test";
import {
  AtlasHybridRouter,
  SentientRuntime,
  sha256Text,
  type ModelAdapter,
  type ModelRequest,
  type ModelResult,
  type PreparedTask,
  type ProviderCapabilities,
} from "../src/index.js";

const capabilities: ProviderCapabilities = {
  text_generation: true, structured_output: false, tool_use: false, tool_continuation: false,
  reasoning_effort: false, image_input: false, server_side_tools: false,
};

class CapturingAtlasAdapter implements ModelAdapter {
  readonly provider = "atlascloud" as const;
  request: ModelRequest | undefined;
  capabilities(): ProviderCapabilities { return capabilities; }
  async generate(request: ModelRequest, model: string): Promise<ModelResult> {
    this.request = request;
    return {
      ok: true, provider: this.provider, model, text: "ok", toolCalls: [],
      usage: { inputTokens: 1, outputTokens: 1, totalTokens: 2 },
      latencyMs: 1, finishReason: "stop", metadata: {},
    };
  }
  async continueWithToolResults(): Promise<ModelResult> { throw new Error("not used"); }
}

test("primary cognition runtime compiles shadow context without changing accepted model request", async () => {
  const source = "expected=g19 actual=g18";
  const context = {
    artifacts: [{
      kind: "evidence" as const, id: "failure", content: source, contentDigest: await sha256Text(source),
      provenance: {
        sourceId: "test-failure", sourceClass: "test_result",
        retrievalMethod: "deterministic", canonicalLocation: "test/state.test.ts",
      },
    }],
    contextDigest: "sha256:runtime-context",
  };
  const task: PreparedTask = {
    taskId: "task-1", sessionId: "session-1", traceId: "trace-1",
    runtime: { name: "sentient", version: "test" },
    systemPolicy: "MODEL_OUTPUT_IS_NEVER_AUTHORITY=true",
    messages: [{ role: "user", content: "Diagnose the exact test failure." }],
    context, tools: [], requiredModelCapabilities: ["text_generation"],
    budget: { maxOutputTokens: 1000, timeoutMs: 10000, maxRetries: 0, maxToolRounds: 0 },
    verifier: { verifierId: "deterministic", configuration: {} },
    inputDigest: "sha256:runtime-input",
  };
  const adapter = new CapturingAtlasAdapter();
  const runtime = new SentientRuntime({ adapters: [adapter] });
  const result = await runtime.executeAdaptive(task, new AtlasHybridRouter(), "cognition");

  assert.ok(result.contextCompilerShadow);
  assert.equal(result.contextCompilerShadowError, undefined);
  assert.equal(result.contextCompilerShadow.shadowMode, true);
  assert.equal(result.contextCompilerShadow.compressor.semanticCompressionEnabled, false);
  assert.equal(result.contextCompilerShadow.retention.decisionRelevantInformationRetention, "PASS");
  assert.equal(result.contextCompilerShadow.sourceContextDigest, task.context.contextDigest);
  assert.ok(result.contextCompilerShadow.constraints.some((x) => x.canonicalIdentity === "runtime:model-messages"));
  assert.ok(result.contextCompilerShadow.constraints.some((x) => x.canonicalIdentity === "runtime:verifier"));
  assert.ok(result.contextCompilerShadow.invariants.some((x) => x.canonicalIdentity === "runtime:system-policy"));

  assert.ok(adapter.request);
  assert.deepEqual(adapter.request.context, task.context);
  assert.deepEqual(adapter.request.messages, task.messages);
  assert.equal(adapter.request.systemPolicy, task.systemPolicy);
  assert.equal(result.preparedTask, task);
  console.log("PRIMARY_RUNTIME_CONTEXT_COMPILER_V0=" + JSON.stringify(result.contextCompilerShadow.accounting));
});
'''

compiler_path.write_text(compiler)
runtime_path.write_text(runtime)
test_path.write_text(test)
