from pathlib import Path

root = Path("sentient")
compiler = root / "src/retrieval/context-compiler-v0.ts"
s = compiler.read_text()
old = 'import type { ContextArtifact, JsonValue } from "../model/types.js";'
new = 'import type { ContextArtifact, JsonValue, PreparedTask } from "../model/types.js";'
if old not in s:
    raise SystemExit("compiler import anchor missing")
s = s.replace(old, new, 1)

marker = 'export async function resolveCompiledContextHandleV0('
if marker not in s:
    raise SystemExit("compiler handle anchor missing")
addition = r'''
function preparedTaskObjectiveV0(task: PreparedTask): string {
  const objective = task.messages
    .filter((message): message is Extract<PreparedTask["messages"][number], { role: "user" }> => message.role === "user")
    .map((message) => message.content)
    .join("\n\n")
    .trim();
  return objective || `task:${task.taskId}`;
}

export async function compilePreparedTaskContextV0(
  task: PreparedTask,
  options: { compressor?: ContextCompressorV0 } = {},
): Promise<CompiledContextV0> {
  const compressor = options.compressor ?? new IdentityContextCompressorV0();
  const artifactInput = { context: task.context, skills: [] } as unknown as ContextCompilerInputV0;
  const c = await compileArtifacts(artifactInput, compressor);
  const objective = preparedTaskObjectiveV0(task);
  const objectiveDigest = await sha256Text(objective);
  const constraintEntries: readonly [string, JsonValue][] = [
    ["runtime:model-messages", jv(task.messages)],
    ["runtime:tools", jv(task.tools)],
    ["runtime:budget", jv(task.budget)],
    ["runtime:verifier", jv(task.verifier)],
    ["runtime:required-model-capabilities", jv(task.requiredModelCapabilities ?? [])],
    ...(task.outputSchema === undefined ? [] : [["runtime:output-schema", jv(task.outputSchema)] as const]),
    ...(task.reasoningEffort === undefined ? [] : [["runtime:reasoning-effort", jv(task.reasoningEffort)] as const]),
    ...(task.cognitivePolicy === undefined ? [] : [["runtime:cognitive-policy", jv(task.cognitivePolicy)] as const]),
  ];
  const invariantEntries: readonly [string, JsonValue][] = [
    ["runtime:system-policy", jv(task.systemPolicy)],
    ["runtime:input-digest", jv(task.inputDigest)],
    ["runtime:identity", jv(task.runtime)],
    ["runtime:task-id", jv(task.taskId)],
    ["runtime:session-id", jv(task.sessionId)],
    ["runtime:trace-id", jv(task.traceId)],
  ];
  const constraints = await Promise.all(constraintEntries.map(async ([canonicalIdentity, value], i) => ({
    alias: `C${i + 1}`, canonicalIdentity, value, digest: await sha256Json(value),
  })));
  const invariants = await Promise.all(invariantEntries.map(async ([canonicalIdentity, value], i) => ({
    alias: `I${i + 1}`, canonicalIdentity, value, digest: await sha256Json(value),
  })));
  const symbols: CompiledContextSymbolV0[] = [
    { alias: "O1", kind: "objective", canonicalIdentity: "sentient:objective", digest: objectiveDigest, sourceHandle: null },
    ...c.symbols,
    ...constraints.map((x) => ({ alias: x.alias, kind: "constraint" as const, canonicalIdentity: x.canonicalIdentity, digest: x.digest, sourceHandle: null })),
    ...invariants.map((x) => ({ alias: x.alias, kind: "invariant" as const, canonicalIdentity: x.canonicalIdentity, digest: x.digest, sourceHandle: null })),
  ];
  const relationships: CompiledContextRelationshipV0[] = [
    ...c.relationships,
    ...constraints.map((x) => ({ from: "O1", relation: "requires_constraint" as const, to: x.alias })),
    ...invariants.map((x) => ({ from: "O1", relation: "preserves_invariant" as const, to: x.alias })),
  ];
  const payload = { objective, artifacts: c.artifacts, constraints, invariants, symbols, relationships, handles: c.handles };
  const rawEnvelope = {
    taskId: task.taskId, sessionId: task.sessionId, traceId: task.traceId, runtime: task.runtime,
    systemPolicy: task.systemPolicy, messages: task.messages, context: task.context, tools: task.tools,
    outputSchema: task.outputSchema ?? null, reasoningEffort: task.reasoningEffort ?? null,
    requiredModelCapabilities: task.requiredModelCapabilities ?? [], budget: task.budget, verifier: task.verifier,
    cognitivePolicy: task.cognitivePolicy ?? null, inputDigest: task.inputDigest,
  };
  const rawContextTokens = jsonTokens(rawEnvelope);
  const compiledContextTokens = jsonTokens(payload);
  const exactEvidenceTokens = c.artifacts.filter((x) => x.lossSensitivity === "EXACT").reduce((n, x) => n + tokens(x.content), 0);
  const semanticCompressibleTokens = c.artifacts
    .filter((x) => x.lossSensitivity === "SEMANTIC_COMPRESSIBLE" || x.lossSensitivity === "SUMMARIZABLE")
    .reduce((n, x) => n + tokens(x.content), 0);
  const invariantRetention = invariants.length === invariantEntries.length && invariants.every((x) => x.digest.length > 0);
  const retention = {
    objectiveRetained: objective.length > 0,
    evidenceRetained: c.artifacts.every((x) => task.context.artifacts.some((a) => a.id === x.artifactId && a.contentDigest === x.contentDigest)),
    constraintRetention: constraints.length === constraintEntries.length && constraints.every((x) => x.digest.length > 0),
    provenanceRetention: c.artifacts.every((x) => x.provenanceDigest.length > 0),
    exactMaterialRetained: c.artifacts.filter((x) => x.lossSensitivity === "EXACT").every((x) => task.context.artifacts.find((a) => a.id === x.artifactId)?.content === x.content && !x.compressed),
    decisionRelevantInformationRetention: "PASS" as "PASS" | "FAIL",
  };
  if (!retention.objectiveRetained || !retention.evidenceRetained || !retention.constraintRetention || !invariantRetention || !retention.provenanceRetention || !retention.exactMaterialRetained) {
    retention.decisionRelevantInformationRetention = "FAIL";
  }
  const semanticCompressionEnabled = c.artifacts.some((x) => x.compressed);
  const base = {
    schemaVersion: CONTEXT_COMPILER_V0_VERSION, shadowMode: true as const,
    objective: { alias: "O1" as const, text: objective, digest: objectiveDigest, lossSensitivity: "EXACT" as const },
    artifacts: c.artifacts, constraints, invariants, symbols, relationships, handles: c.handles,
    accounting: {
      tokenEstimator: "ceil_utf8_bytes_div_4" as const, rawContextTokens, compiledContextTokens, exactEvidenceTokens,
      structuralTokens: jsonTokens({ symbols, relationships, handles: c.handles }), semanticCompressibleTokens,
      compressedNarrativeTokens: c.artifacts.filter((x) => x.compressed).reduce((n, x) => n + tokens(x.content), 0),
      contextCompressionRatio: rawContextTokens === 0 ? 1 : compiledContextTokens / rawContextTokens,
    },
    retention,
    compressor: {
      id: compressor.id, semanticCompressionEnabled,
      reason: semanticCompressionEnabled ? "explicit compressor transformed semantic-compressible segments" : "IdentityCompressor preserves narrative content in Context Compiler V0",
    },
    sourceContextDigest: task.context.contextDigest,
  };
  return { ...base, compilerDigest: await sha256Json(base) };
}

'''
s = s.replace(marker, addition + marker, 1)
compiler.write_text(s)

runtime = root / "src/runtime/sentient-runtime.ts"
r = runtime.read_text()
anchor = 'import { rebudgetContextBundle } from "../retrieval/context-builder.js";'
replacement = anchor + '\nimport { compilePreparedTaskContextV0 } from "../retrieval/context-compiler-v0.js";\nimport type { CompiledContextV0 } from "../retrieval/context-compiler-v0-contracts.js";'
if anchor not in r:
    raise SystemExit("runtime import anchor missing")
r = r.replace(anchor, replacement, 1)

anchor = '''export interface AdaptiveRuntimeResult extends AtlasHybridExecution {
  preparedTask: PreparedTask;
  cognitiveState?: RuntimeCognitiveState;
}'''
replacement = '''export interface AdaptiveRuntimeResult extends AtlasHybridExecution {
  preparedTask: PreparedTask;
  cognitiveState?: RuntimeCognitiveState;
  contextCompilerShadow?: CompiledContextV0;
  contextCompilerShadowError?: string;
}'''
if anchor not in r:
    raise SystemExit("adaptive result anchor missing")
r = r.replace(anchor, replacement, 1)

anchor = '''    if (policy === undefined) {
      const execution = await router.execute(this, preparedTask, stage);
      return { ...execution, preparedTask };
    }'''
replacement = '''    if (policy === undefined) {
      const contextCompilerShadow = await compileRuntimeContextShadowV0(preparedTask, stage);
      const execution = await router.execute(this, preparedTask, stage);
      return { ...execution, preparedTask, ...contextCompilerShadow };
    }'''
if anchor not in r:
    raise SystemExit("policy branch anchor missing")
r = r.replace(anchor, replacement, 1)

anchor = '''    const executor = {
      execute: async (task: PreparedTask, target: ProviderTarget): Promise<RuntimeResult> => {'''
replacement = '''    const contextCompilerShadow = await compileRuntimeContextShadowV0(adaptiveTask, stage);

    const executor = {
      execute: async (task: PreparedTask, target: ProviderTarget): Promise<RuntimeResult> => {'''
if anchor not in r:
    raise SystemExit("executor anchor missing")
r = r.replace(anchor, replacement, 1)

anchor = '''    return {
      ...execution,
      preparedTask: adaptiveTask,
      cognitiveState,
    };
  }'''
replacement = '''    return {
      ...execution,
      preparedTask: adaptiveTask,
      cognitiveState,
      ...contextCompilerShadow,
    };
  }'''
if anchor not in r:
    raise SystemExit("adaptive return anchor missing")
r = r.replace(anchor, replacement, 1)

marker = 'function reasoningEffortForAllocation(cognition: number): ReasoningEffort {'
helper = '''async function compileRuntimeContextShadowV0(
  task: PreparedTask,
  stage: AtlasHybridStage,
): Promise<{ contextCompilerShadow?: CompiledContextV0; contextCompilerShadowError?: string }> {
  if (stage !== "cognition") return {};
  try {
    const compiled = await compilePreparedTaskContextV0(task);
    if (compiled.sourceContextDigest !== task.context.contextDigest) {
      throw new Error("context_compiler_shadow_context_digest_mismatch");
    }
    if (compiled.retention.decisionRelevantInformationRetention !== "PASS") {
      throw new Error("context_compiler_shadow_retention_failed");
    }
    return { contextCompilerShadow: compiled };
  } catch (error) {
    return {
      contextCompilerShadowError: error instanceof Error ? error.message : String(error),
    };
  }
}

'''
if marker not in r:
    raise SystemExit("runtime helper anchor missing")
r = r.replace(marker, helper + marker, 1)
runtime.write_text(r)

test = root / "test/context-runtime-shadow-v0.test.ts"
test.write_text(r'''import assert from "node:assert/strict";
import test from "node:test";
import {
  AtlasHybridRouter,
  SentientRuntime,
  sha256Json,
  sha256Text,
  type ModelAdapter,
  type ModelRequest,
  type ModelResult,
  type PreparedTask,
  type ProviderCapabilities,
  type ToolResult,
} from "../src/index.js";

const capabilities: ProviderCapabilities = {
  text_generation: true,
  structured_output: true,
  tool_use: true,
  tool_continuation: true,
  reasoning_effort: true,
  image_input: false,
  server_side_tools: false,
};

test("primary cognition runtime constructs compiled context in shadow without changing the model request", async () => {
  const content = "expected=g19\\nactual=g18";
  const artifact = {
    kind: "evidence" as const,
    id: "test-failure",
    content,
    contentDigest: await sha256Text(content),
    provenance: {
      sourceId: "repo",
      sourceClass: "test_result",
      retrievalMethod: "deterministic",
      canonicalLocation: "test/state.test.ts",
    },
  };
  const context = {
    artifacts: [artifact],
    contextDigest: await sha256Json({ artifacts: [artifact] }),
  };
  const task: PreparedTask = {
    taskId: "primary-shadow",
    sessionId: "session",
    traceId: "trace",
    runtime: { name: "sentient", version: "test" },
    systemPolicy: "MODEL_OUTPUT_IS_NEVER_AUTHORITY=true",
    messages: [{ role: "user", content: "Diagnose the failing state transition." }],
    context,
    tools: [],
    requiredModelCapabilities: ["text_generation"],
    budget: { maxOutputTokens: 256, timeoutMs: 5_000, maxRetries: 0, maxToolRounds: 0 },
    verifier: { verifierId: "deterministic", configuration: {} },
    inputDigest: await sha256Text("primary-shadow"),
  };
  let observed: ModelRequest | undefined;
  const success = (_request: ModelRequest, model: string): ModelResult => ({
    ok: true,
    provider: "atlascloud",
    model,
    text: "ok",
    toolCalls: [],
    usage: { inputTokens: 1, outputTokens: 1, totalTokens: 2 },
    latencyMs: 1,
    finishReason: "stop",
    metadata: {},
  });
  const adapter: ModelAdapter = {
    provider: "atlascloud",
    capabilities: () => capabilities,
    generate: async (request, model) => {
      observed = request;
      return success(request, model);
    },
    continueWithToolResults: async (request: ModelRequest, model: string, _previous, _toolResults: readonly ToolResult[]) => success(request, model),
  };
  const runtime = new SentientRuntime({ adapters: [adapter] });
  const result = await runtime.executeAdaptive(task, new AtlasHybridRouter(), "cognition");

  assert.equal(result.contextCompilerShadowError, undefined);
  assert.ok(result.contextCompilerShadow);
  assert.equal(result.contextCompilerShadow.shadowMode, true);
  assert.equal(result.contextCompilerShadow.sourceContextDigest, context.contextDigest);
  assert.equal(result.contextCompilerShadow.retention.decisionRelevantInformationRetention, "PASS");
  assert.equal(result.contextCompilerShadow.compressor.semanticCompressionEnabled, false);
  assert.ok(result.contextCompilerShadow.constraints.some((x) => x.canonicalIdentity === "runtime:model-messages"));
  assert.ok(result.contextCompilerShadow.constraints.some((x) => x.canonicalIdentity === "runtime:verifier"));
  assert.ok(result.contextCompilerShadow.invariants.some((x) => x.canonicalIdentity === "runtime:system-policy"));
  assert.deepEqual(observed?.context, task.context);
  assert.deepEqual(observed?.messages, task.messages);
  assert.equal(observed?.systemPolicy, task.systemPolicy);
  assert.equal(result.preparedTask.context.contextDigest, task.context.contextDigest);
});
''')
