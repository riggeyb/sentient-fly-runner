
from pathlib import Path

def replace_once(path, old, new):
    p=Path(path); s=p.read_text()
    n=s.count(old)
    if n!=1: raise SystemExit(f"{path}: expected 1 match, got {n}: {old[:120]!r}")
    p.write_text(s.replace(old,new,1))

replace_once("src/model/invocation-envelope.ts",
'''  maxInputTokens: number | null;
  maxOutputTokens: number | null;
  maxCostMicros: number | null;''',
'''  maxInputTokens: number | null;
  maxOutputTokens: number | null;
  maxTotalTokens: number | null;
  maxCostMicros: number | null;''')
replace_once("src/model/invocation-envelope.ts",
'''  maxInputTokens?: number | null;
  maxOutputTokens?: number | null;
  maxCostMicros?: number | null;''',
'''  maxInputTokens?: number | null;
  maxOutputTokens?: number | null;
  maxTotalTokens?: number | null;
  maxCostMicros?: number | null;''')
replace_once("src/model/invocation-envelope.ts",
'''    ["maxInputTokens", input.maxInputTokens],
    ["maxOutputTokens", input.maxOutputTokens],
    ["maxCostMicros", input.maxCostMicros],''',
'''    ["maxInputTokens", input.maxInputTokens],
    ["maxOutputTokens", input.maxOutputTokens],
    ["maxTotalTokens", input.maxTotalTokens],
    ["maxCostMicros", input.maxCostMicros],''')
replace_once("src/model/invocation-envelope.ts",
'''    maxInputTokens: input.maxInputTokens ?? null,
    maxOutputTokens: input.maxOutputTokens ?? null,
    maxCostMicros: input.maxCostMicros ?? null,''',
'''    maxInputTokens: input.maxInputTokens ?? null,
    maxOutputTokens: input.maxOutputTokens ?? null,
    maxTotalTokens: input.maxTotalTokens ?? null,
    maxCostMicros: input.maxCostMicros ?? null,''')
replace_once("src/model/invocation-envelope.ts",
'''    ...(envelope.maxInputTokens === null ? {} : { sentientMaxInputTokens: envelope.maxInputTokens }),
    ...(envelope.maxOutputTokens === null ? {} : { sentientMaxOutputTokens: envelope.maxOutputTokens }),
    ...(envelope.maxCostMicros === null ? {} : { sentientMaxCostMicros: envelope.maxCostMicros }),''',
'''    ...(envelope.maxInputTokens === null ? {} : { sentientMaxInputTokens: envelope.maxInputTokens }),
    ...(envelope.maxOutputTokens === null ? {} : { sentientMaxOutputTokens: envelope.maxOutputTokens }),
    ...(envelope.maxTotalTokens === null ? {} : { sentientMaxTotalTokens: envelope.maxTotalTokens }),
    ...(envelope.maxCostMicros === null ? {} : { sentientMaxCostMicros: envelope.maxCostMicros }),''')

replace_once("src/phase3/cognitive-components.ts",
'''import type { PinnedSkillRegistry } from "../retrieval/contracts.js";''',
'''import type { PinnedSkillRegistry } from "../retrieval/contracts.js";
import type { ModelInvocationEnvelopeV1 } from "../model/invocation-envelope.js";''')
replace_once("src/phase3/cognitive-components.ts",
'''export interface HfPortV1{classify<L extends string>(input:{component:CognitiveComponentV1;text:string;allowedLabels:readonly L[]}):Promise<HfPredictionV1<L>>}''',
'''export interface HfPortV1{classify<L extends string>(input:{component:CognitiveComponentV1;text:string;allowedLabels:readonly L[];invocation?:ModelInvocationEnvelopeV1}):Promise<HfPredictionV1<L>>}''')

replace_once("src/model/providers/atlas-cloud-client.ts",
'''  systemPrompt: string;
  userPrompt: string;
  maxOutputTokens: number;''',
'''  systemPrompt: string;
  userPrompt: string;
  maxInputTokens?: number;
  maxOutputTokens: number;
  maxTotalTokens?: number;''')
replace_once("src/model/providers/atlas-cloud-client.ts",
'''    if (!Number.isInteger(input.maxOutputTokens) || input.maxOutputTokens <= 0) {
      throw new Error("atlascloud_max_output_tokens_invalid");
    }
    if (!Number.isFinite(input.timeoutMs) || input.timeoutMs <= 0) {''',
'''    if (
      input.maxInputTokens !== undefined
      && (!Number.isSafeInteger(input.maxInputTokens) || input.maxInputTokens <= 0)
    ) throw new Error("atlascloud_max_input_tokens_invalid");
    if (!Number.isInteger(input.maxOutputTokens) || input.maxOutputTokens <= 0) {
      throw new Error("atlascloud_max_output_tokens_invalid");
    }
    if (
      input.maxTotalTokens !== undefined
      && (!Number.isSafeInteger(input.maxTotalTokens) || input.maxTotalTokens <= 0)
    ) throw new Error("atlascloud_max_total_tokens_invalid");
    if (!Number.isFinite(input.timeoutMs) || input.timeoutMs <= 0) {''')
replace_once("src/model/providers/atlas-cloud-client.ts",
'''    const timeoutSignal = AbortSignal.timeout(input.timeoutMs);''',
'''    // Tokenizers differ by provider. UTF-8 bytes plus a fixed chat-envelope allowance
    // is a conservative upper bound used only to reject before network dispatch.
    const conservativeInputUpperBound =
      Buffer.byteLength(input.systemPrompt, "utf8")
      + Buffer.byteLength(input.userPrompt, "utf8")
      + 64;
    if (
      input.maxInputTokens !== undefined
      && conservativeInputUpperBound > input.maxInputTokens
    ) {
      return this.#failure(model, "context_limit", "atlascloud_input_token_ceiling_exceeded_before_dispatch", started, null);
    }
    const outputCeiling = input.maxTotalTokens === undefined
      ? input.maxOutputTokens
      : Math.min(input.maxOutputTokens, input.maxTotalTokens - conservativeInputUpperBound);
    if (outputCeiling <= 0) {
      return this.#failure(model, "context_limit", "atlascloud_total_token_ceiling_exhausted_before_dispatch", started, null);
    }

    const timeoutSignal = AbortSignal.timeout(input.timeoutMs);''')
replace_once("src/model/providers/atlas-cloud-client.ts",
'''          max_tokens: input.maxOutputTokens,''',
'''          max_tokens: outputCeiling,''')
replace_once("src/model/providers/atlas-cloud-client.ts",
'''    return {
      ok: true,
      provider: "atlascloud",
      model,
      text,
      structuredOutput,
      structuredOutputValid: true,
      usage: parseUsage(record(row.usage)),''',
'''    const usage = parseUsage(record(row.usage));
    if (
      (input.maxInputTokens !== undefined && usage.inputTokens !== null && usage.inputTokens > input.maxInputTokens)
      || (input.maxTotalTokens !== undefined && usage.totalTokens !== null && usage.totalTokens > input.maxTotalTokens)
    ) {
      return this.#failure(model, "context_limit", "atlascloud_reported_tokens_exceeded_limit", started, providerRequestId);
    }

    return {
      ok: true,
      provider: "atlascloud",
      model,
      text,
      structuredOutput,
      structuredOutputValid: true,
      usage,''')

replace_once("src/model/providers/atlas-hybrid-router.ts",
'''  maxInputTokens?: number;
  maxOutputTokens?: number;
  maxCostMicros?: number;''',
'''  maxInputTokens?: number;
  maxOutputTokens?: number;
  maxTotalTokens?: number;
  maxCostMicros?: number;''')
replace_once("src/model/providers/atlas-hybrid-router.ts",
'''          maxOutputTokens: Math.min(input.maxOutputTokens ?? step.maxOutput, step.maxOutput),
          timeoutMs: attemptMs,''',
'''          ...(input.maxInputTokens === undefined ? {} : { maxInputTokens: input.maxInputTokens }),
          maxOutputTokens: Math.min(input.maxOutputTokens ?? step.maxOutput, step.maxOutput),
          ...(input.maxTotalTokens === undefined ? {} : { maxTotalTokens: input.maxTotalTokens }),
          timeoutMs: attemptMs,''')
replace_once("src/model/providers/atlas-hybrid-router.ts",
'''      const localStarted = Date.now();
      try {
        const completion = await this.#local.complete({
          systemPrompt: localPrompt(defaultStage, input.systemPrompt),
          userPrompt: input.userPrompt,
          maxInputTokens: input.maxInputTokens ?? 4_096,
          maxOutputTokens: Math.min(input.maxOutputTokens ?? step.maxOutput, step.maxOutput),
          signal: attemptSignal,
        });''',
'''      const localStarted = Date.now();
      try {
        const requestedOutput = Math.min(input.maxOutputTokens ?? step.maxOutput, step.maxOutput);
        const totalCeiling = input.maxTotalTokens;
        if (totalCeiling !== undefined && totalCeiling < 2) {
          fallbackReason = "context_limit";
          continue;
        }
        const localOutputCeiling = totalCeiling === undefined
          ? requestedOutput
          : Math.min(requestedOutput, Math.max(1, totalCeiling - 1));
        const localInputCeiling = totalCeiling === undefined
          ? (input.maxInputTokens ?? 4_096)
          : Math.min(input.maxInputTokens ?? 4_096, Math.max(1, totalCeiling - localOutputCeiling));
        const completion = await this.#local.complete({
          systemPrompt: localPrompt(defaultStage, input.systemPrompt),
          userPrompt: input.userPrompt,
          maxInputTokens: localInputCeiling,
          maxOutputTokens: localOutputCeiling,
          signal: attemptSignal,
        });''')

replace_once("src/model/providers/atlas-hybrid-adapters.ts",
'''  public async run(requirements: TaskRequirementsV1, invocation?: ModelInvocationEnvelopeV1): Promise<unknown> {
    if (invocation && !modelInvocationLiveV1(invocation)) return unavailable("invocation_dead_before_dispatch");
    const controls = invocationControls(invocation);''',
'''  public async run(requirements: TaskRequirementsV1, invocation?: ModelInvocationEnvelopeV1): Promise<unknown> {
    if (invocation && !modelInvocationLiveV1(invocation)) return unavailable("invocation_dead_before_dispatch");
    if (
      invocation
      && (invocation.maxInputTokens === 0 || invocation.maxOutputTokens === 0 || invocation.maxTotalTokens === 0)
    ) return unavailable("token_budget_exhausted");
    const controls = invocationControls(invocation);''')
replace_once("src/model/providers/atlas-hybrid-adapters.ts",
'''  public async classify<L extends string>(input: {
    component: CognitiveComponentV1;
    text: string;
    allowedLabels: readonly L[];
  }): Promise<HfPredictionV1<L>> {''',
'''  public async classify<L extends string>(input: {
    component: CognitiveComponentV1;
    text: string;
    allowedLabels: readonly L[];
    invocation?: ModelInvocationEnvelopeV1;
  }): Promise<HfPredictionV1<L>> {''')
replace_once("src/model/providers/atlas-hybrid-adapters.ts",
'''    if (!input.allowedLabels.length) throw new Error("phase3_labels_required");
    const labels = new Set<string>(input.allowedLabels);
    const result = await this.#router.cognition({''',
'''    if (!input.allowedLabels.length) throw new Error("phase3_labels_required");
    if (input.invocation && !modelInvocationLiveV1(input.invocation)) throw new Error("phase3_invocation_dead");
    if (input.invocation?.maxTotalTokens === 0) throw new Error("phase3_token_budget_exhausted");
    const labels = new Set<string>(input.allowedLabels);
    const controls = invocationControls(input.invocation);
    const result = await this.#router.cognition({''')
replace_once("src/model/providers/atlas-hybrid-adapters.ts",
'''      userPrompt: input.text,
      maxOutputTokens: 32,
      requiredTextValidator: (text) => labels.has(text.trim()),''',
'''      userPrompt: input.text,
      maxInputTokens: boundedTokens(4_096, input.invocation?.maxInputTokens),
      maxOutputTokens: boundedTokens(32, input.invocation?.maxOutputTokens),
      ...(input.invocation?.maxTotalTokens === null || input.invocation?.maxTotalTokens === undefined
        ? {}
        : { maxTotalTokens: input.invocation.maxTotalTokens }),
      ...controls,
      requiredTextValidator: (text) => labels.has(text.trim()),''')
replace_once("src/model/providers/atlas-hybrid-adapters.ts",
'''      maxInputTokens: Math.min(budget.maxInputTokens, 8_192),
      maxOutputTokens: Math.min(budget.maxOutputTokens, verification ? 32 : 384),
      maxCostMicros: budget.maxCostMicros,''',
'''      maxInputTokens: Math.min(budget.maxInputTokens, 8_192),
      maxOutputTokens: Math.min(budget.maxOutputTokens, verification ? 32 : 384),
      maxTotalTokens: budget.maxTotalTokens,
      maxCostMicros: budget.maxCostMicros,''')
replace_once("src/model/providers/atlas-hybrid-adapters.ts",
'''function invocationControls(invocation: ModelInvocationEnvelopeV1 | undefined): { timeoutMs?: number; maxCostMicros?: number; signal?: AbortSignal } {
  if (!invocation) return {};
  const remaining=modelInvocationRemainingMsV1(invocation);
  return { timeoutMs: Math.max(1,Math.min(invocation.maxWallTimeMs,remaining)), ...(invocation.maxCostMicros===null?{}:{maxCostMicros:invocation.maxCostMicros}), signal:invocation.signal };
}
function boundedTokens(defaultValue:number,inherited:number|null|undefined):number {
  return inherited===null||inherited===undefined?defaultValue:Math.max(1,Math.min(defaultValue,inherited));
}''',
'''function invocationControls(invocation: ModelInvocationEnvelopeV1 | undefined): { timeoutMs?: number; maxCostMicros?: number; maxTotalTokens?: number; signal?: AbortSignal } {
  if (!invocation) return {};
  const remaining=modelInvocationRemainingMsV1(invocation);
  return {
    timeoutMs: Math.max(1,Math.min(invocation.maxWallTimeMs,remaining)),
    ...(invocation.maxCostMicros===null?{}:{maxCostMicros:invocation.maxCostMicros}),
    ...(invocation.maxTotalTokens===null?{}:{maxTotalTokens:invocation.maxTotalTokens}),
    signal:invocation.signal,
  };
}
function boundedTokens(defaultValue:number,inherited:number|null|undefined):number {
  return inherited===null||inherited===undefined?defaultValue:Math.max(0,Math.min(defaultValue,inherited));
}''')

replace_once("src/application/production-composition.ts",
'''import {completeProductionObjectiveStateV1,ensureProductionObjectiveContinuationV1,ensureProductionObjectiveStateV1} from "./production-state.js";''',
'''import {completeProductionObjectiveStateV1,ensureProductionObjectiveContinuationV1,ensureProductionObjectiveStateV1} from "./production-state.js";
import { resolveObjectiveBudgetV1 } from "./objective-budget.js";
import { createModelInvocationEnvelopeV1 } from "../model/invocation-envelope.js";''')
replace_once("src/application/production-composition.ts",
'''  const phase1=await runProductionPhase1TurnV1(i,o.cognition,o.phase1AcceptancePolicy??null);
  const phase3Assessment=await assessPhase1ResultWithPhase3V1(phase1,o.phase3);''',
'''  const phase1=await runProductionPhase1TurnV1(i,o.cognition,o.phase1AcceptancePolicy??null);
  const phase3Assessment=await assessPhase1ResultWithPhase3V1(phase1,o.phase3,i);''')
replace_once("src/application/production-composition.ts",
''' async function runObjective(i:SentientObjectiveInput):Promise<SentientApplicationResult>{
  validateObjectiveInput(i);const mode=routeSentientObjectiveV1(i.mode,i.request),d=o.state;
  if(!readiness().ready||!d)return{httpStatus:503,body:{mode,result:{contractVersion:SENTIENT_APPLICATION_CONTRACT,objectiveId:i.objectiveId,status:"APPLICATION_NOT_READY",authorityOwner:"SENTIENT_RUNTIME",authoritativeResultRef:null,authoritativeContent:null,readiness:readiness()}}};
  await ensureProductionObjectiveStateV1(d,i,o.identity);let result:unknown;
  try{result=await runMode(d,i,mode)}catch(e){if(!(e instanceof ProductionEvidenceGap))throw e;result=Object.freeze({contractVersion:SENTIENT_APPLICATION_CONTRACT,objectiveId:i.objectiveId,status:"UNAVAILABLE" as const,authorityOwner:"SENTIENT_RUNTIME" as const,authoritativeResultRef:null,authoritativeContent:null,evidenceRefs:Object.freeze([] as string[]),reason:e.gap,continuation:(await d.getObjectiveContinuation(i.objectiveId))??null})}
  const httpStatus=http(result);await completeProductionObjectiveStateV1(d,i.objectiveId,httpStatus,result);return{httpStatus,body:{mode,result}};
 }''',
''' async function runObjective(i:SentientObjectiveInput):Promise<SentientApplicationResult>{
  validateObjectiveInput(i);
  const objectiveBudget=resolveObjectiveBudgetV1(i);
  const boundedInput:SentientObjectiveInput=Object.freeze({...i,deadline:objectiveBudget.absoluteDeadline});
  const mode=routeSentientObjectiveV1(boundedInput.mode,boundedInput.request),d=o.state;
  if(!readiness().ready||!d)return{httpStatus:503,body:{mode,result:{contractVersion:SENTIENT_APPLICATION_CONTRACT,objectiveId:boundedInput.objectiveId,status:"APPLICATION_NOT_READY",authorityOwner:"SENTIENT_RUNTIME",authoritativeResultRef:null,authoritativeContent:null,readiness:readiness()}}};
  await ensureProductionObjectiveStateV1(d,boundedInput,o.identity);let result:unknown;
  try{result=await runMode(d,boundedInput,mode)}catch(e){if(!(e instanceof ProductionEvidenceGap))throw e;result=Object.freeze({contractVersion:SENTIENT_APPLICATION_CONTRACT,objectiveId:boundedInput.objectiveId,status:"UNAVAILABLE" as const,authorityOwner:"SENTIENT_RUNTIME" as const,authoritativeResultRef:null,authoritativeContent:null,evidenceRefs:Object.freeze([] as string[]),reason:e.gap,continuation:(await d.getObjectiveContinuation(boundedInput.objectiveId))??null})}
  const httpStatus=http(result);await completeProductionObjectiveStateV1(d,boundedInput.objectiveId,httpStatus,result);return{httpStatus,body:{mode,result}};
 }''')
replace_once("src/application/production-composition.ts",
'''export function runProductionPhase1TurnV1(i:SentientObjectiveInput,cognition:Phase1CognitionPort,acceptancePolicy?:Phase1AcceptancePolicyV1|null):Promise<SentientTurnResultV1>{
 return executeSentientPhase1TurnV1(
  {requestId:`request:${i.objectiveId}`,sessionId:i.sessionId,taskId:i.objectiveId,userRequest:i.request},
  {cognition,...(acceptancePolicy?{acceptancePolicy}:{})},
 );
}''',
'''export function runProductionPhase1TurnV1(i:SentientObjectiveInput,cognition:Phase1CognitionPort,acceptancePolicy?:Phase1AcceptancePolicyV1|null):Promise<SentientTurnResultV1>{
 const budget=resolveObjectiveBudgetV1(i);
 const invocation=createModelInvocationEnvelopeV1({
  objectiveId:i.objectiveId,
  executionId:`root-cognition:${i.objectiveId}`,
  invocationId:`root-cognition:${i.objectiveId}`,
  role:"root-cognition",
  model:null,
  absoluteDeadline:budget.absoluteDeadline,
  maxWallTimeMs:Math.max(1,budget.maxDurationMs),
  maxInputTokens:budget.maxTokens,
  maxOutputTokens:budget.maxTokens,
  maxTotalTokens:budget.maxTokens,
  maxCostMicros:budget.maxCostMicros,
 });
 return executeSentientPhase1TurnV1(
  {requestId:`request:${i.objectiveId}`,sessionId:i.sessionId,taskId:i.objectiveId,userRequest:i.request},
  {cognition,...(acceptancePolicy?{acceptancePolicy}:{}),invocation},
 );
}''')
replace_once("src/application/production-composition.ts",
'''export async function assessPhase1ResultWithPhase3V1(turn:SentientTurnResultV1,phase3:HfPortV1|undefined|null):Promise<ProductionPhase3AssessmentV1>{''',
'''export async function assessPhase1ResultWithPhase3V1(turn:SentientTurnResultV1,phase3:HfPortV1|undefined|null,objective?:SentientObjectiveInput):Promise<ProductionPhase3AssessmentV1>{''')
replace_once("src/application/production-composition.ts",
''' try{const prediction=await phase3.classify({component:"RESULT_CLASSIFIER",text,allowedLabels:RESULT_LABELS});return Object.freeze({...base,status:"ASSESSED" as const,label:prediction.label,modelId:prediction.modelId,transport:prediction.transport,reason:null});}''',
''' try{
  const invocation=objective===undefined?undefined:(()=>{
   const budget=resolveObjectiveBudgetV1(objective);
   return createModelInvocationEnvelopeV1({
    objectiveId:objective.objectiveId,
    executionId:`root-phase3:${objective.objectiveId}`,
    invocationId:`root-phase3:${objective.objectiveId}`,
    role:"verifier",
    model:null,
    absoluteDeadline:budget.absoluteDeadline,
    maxWallTimeMs:Math.max(1,budget.maxDurationMs),
    maxInputTokens:budget.maxTokens,
    maxOutputTokens:budget.maxTokens===null?32:Math.min(32,budget.maxTokens),
    maxTotalTokens:budget.maxTokens,
    maxCostMicros:budget.maxCostMicros,
   });
  })();
  const prediction=await phase3.classify({component:"RESULT_CLASSIFIER",text,allowedLabels:RESULT_LABELS,...(invocation===undefined?{}:{invocation})});
  return Object.freeze({...base,status:"ASSESSED" as const,label:prediction.label,modelId:prediction.modelId,transport:prediction.transport,reason:null});
 }''')

Path("test/dynamic-objective-model-envelope.test.ts").write_text(r'''import assert from "node:assert/strict";
import test from "node:test";
import { createModelInvocationEnvelopeV1, modelInvocationConstraintsV1 } from "../src/model/invocation-envelope.js";
import { AtlasCloudClientV1 } from "../src/model/providers/atlas-cloud-client.js";

test("model invocation total token ceiling is externally represented", () => {
  const invocation=createModelInvocationEnvelopeV1({
    objectiveId:"o",executionId:"e",invocationId:"i",role:"root",model:null,
    absoluteDeadline:new Date(Date.now()+5_000).toISOString(),maxWallTimeMs:5_000,
    maxInputTokens:100,maxOutputTokens:40,maxTotalTokens:120,maxCostMicros:50,
  });
  assert.equal(invocation.maxTotalTokens,120);
  assert.equal(modelInvocationConstraintsV1(invocation).sentientMaxTotalTokens,120);
});

test("Atlas rejects conservative input ceiling before network dispatch", async () => {
  let calls=0;
  const client=new AtlasCloudClientV1({
    apiKey:"not-a-secret",
    fetchImpl:(async()=>{calls+=1; throw new Error("must not dispatch")}) as typeof fetch,
  });
  const result=await client.complete({
    model:"deepseek-ai/deepseek-v3.2",
    systemPrompt:"system prompt",
    userPrompt:"this prompt is deliberately longer than one token",
    maxInputTokens:1,
    maxOutputTokens:16,
    maxTotalTokens:17,
    timeoutMs:1_000,
  });
  assert.equal(result.ok,false);
  assert.equal(calls,0);
});
''')
print("PATCH_A_READY")
